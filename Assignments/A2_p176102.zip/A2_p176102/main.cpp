#include <iostream>
#include "perssonlist.h"
using namespace std;


int main() {
	
	cout << "\n\n--------------------------------------------------\n" << endl;
	cout << "\t Greetings t0 MinI NaDrA SyStEm" << endl;
	cout << "\n--------------------------------------------------\n" << endl;
	
	personList p;
	p.append(1234, "Ali", "Abu ALi", 'M', "Peshawar");
	p.addNumber("Ali", 1234, "Jazz");
	p.addNumber("Ali", 12231, "Ufone");	
	
	p.append(5678, "Ahmad", "Abu Ahmad", 'M', "Hayyatabad");
	p.addNumber("Ahmad", 321, "Telenor");
	p.addNumber("Ahmad", 45612234, "Telenor");
	
	p.append(12343, "Abdullah", "Abu Abdullah", 'M', "Lahore");
	p.addNumber("Abdullah", 243424, "Zong");
	p.addNumber("Abdullah", 32423423, "Telenor");

	p.append(12342, "Arsalan", "Abu Abdullah", 'M', "Lahore");
	p.addNumber("Arsalan", 243424, "Zong");
	p.addNumber("Arsalan", 3242342, "Telenor");	
	
	p.append(12392, "Waleed", "Abu Abdullah", 'M', "Lahore");
	p.addNumber("Waleed", 90078601, "Zong");
	p.addNumber("Waleed", 58789654, "Telenor");
	
//	
	p.append(12391, "Zia", "Abu Abdullah", 'M', "Sialkot");
	p.addNumber("Zia", 22999990, "Zong");
	p.addNumber("Zia", 12487278, "Telenor");
//	
	p.append(5465654, "Osama ", "Abu Abdullah", 'M', "Sahiwal");
//	p.addNumber("Osama", 030024555, "Jazz");
//	p.addNumber("Osama", 032222424, "Telenor");
//	
	p.append(12391, "Hamza ", "Abu Abdullah", 'M', "Islamabad");
//	p.addNumber("Hamza", 3109255, "Jazz");
//	p.addNumber("Hamza", 9996425, "Telenor");
//	
//	p.append(12391, "Shahwaiz ", "Abu Abdullah", 'M', "Islamabad");
//	p.addNumber("Shahwaiz", 3109255, "Jazz");
//	p.addNumber("Shahwaiz", 1988888, "Telenor");
//	p.addNumber("Shahwaiz", 33323311, "Ufone");
////	p.addNumber("Shahwaiz", 3339923, "Zong");
//	
//	p.append(12391, "Haris ", "Abu Abdullah", 'M', "Islamabad");
//	p.addNumber("Haris", 8888234, "Jazz");
//	p.addNumber("Haris", 7893222, "Telenor");
//	
//	p.append(12391, "Been ", "Abu Abdullah", 'M', "Islamabad");
//	p.addNumber("Been", 1425414, "Jazz");
//	p.addNumber("Been", 14541000, "Telenor");
	

	
	
	p.print();
//	p.changeNetwork("Ali",1234, "New Network");
//	p.updateAddress("Ali", "Lahore");
//	p.print();
//	
//	cout << "********************************************************************* " << endl;
//	
//	p.deletePerson(1234);
//	p.print();
//	cout << "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" << endl;
//	//p.deleteCell(321);
//	//p.print();
//	cout << ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,," << endl;
//	p.deleteAll();
	
	
}
