#include <iostream>
#include <string>
#include <fstream>
using namespace std;

struct CellNode {
	int CellNumber; //( 5 digit number, different for everyone)
	string NetworkName; // (4 are allowed. Telenor, Jazz, Ufone, Zong)
	CellNode* Down;
	
};



struct PersonNode{
	int CNIC; 					//( 4 digit number, different for everyone)
	string name;
	string FatherName;
	char gender;
	string address;				//(address should be short, e.g. Bahira Town Peshawar)
	PersonNode* next;
	CellNode* down;
};

class personList{
private:
	PersonNode * head;
public:
	personList() {
		head = NULL;
	}

	void append(int cnic, string name, string fname, char gen, string add ) {
		if (head == NULL) {
			
			PersonNode* temp = new PersonNode;
			temp->CNIC = cnic;
			temp->name = name;
			temp->FatherName = fname;
			temp->gender = gen;
			temp->address = add;
			temp->next = NULL;
			temp->down = NULL;
			head = temp;
			
		}
		
		else {
			
			PersonNode* temp = new PersonNode;
			temp = head;
			while(temp->next != NULL) {
				temp = temp->next;
			}
			PersonNode* temp2 = new PersonNode;
			temp2->CNIC = cnic;
			temp2->name = name;
			temp2->FatherName = fname;
			temp2->gender = gen;
			temp2->address = add;
			temp2->next = NULL;
			temp2->down = NULL;
			temp->next = temp2;
			
			int count = 0;
			
//			cout << "\nEnter Numbers for " << name << endl;
//			
//			while(count != 3) {
//				temp2->down =  addCellNode(temp2->down);
//				count ++;
//			}
				
		}
	}

	
	void print() {
		
		PersonNode* temp = new PersonNode;
		temp = head;
		
		while(temp != NULL) {
			cout << "\nName : " << temp->name << endl;
			cout << "FatherName : " << temp->FatherName << endl;
			cout << "CNIC : " << temp->CNIC << endl;
			cout << "gender : " << temp->gender << endl;		
			cout << "address : " << temp->address << endl;
			
			CellNode* ctemp = new CellNode;
			ctemp = temp->down;
			
			while(ctemp != NULL) {
				cout <<"\t-> " << ctemp->NetworkName << " - " << ctemp->CellNumber << endl;
				ctemp = ctemp->Down;
			}
			
		

			temp = temp->next;
			
			cout << "\n--------------------------------------------" << endl;
		}
	}
	
	void changeNetwork(string name, int num, string newNetwork) {
		
		PersonNode* temp = new PersonNode;
		temp = head;
		
		while(temp->name != name) {
			temp = temp->next;
		}
		
		CellNode* ctemp = new CellNode;
		ctemp = temp->down;
		while(ctemp->CellNumber != num) {
			ctemp = ctemp->Down;
		}
		ctemp->NetworkName = newNetwork;
		
	}	
	
	void deletePerson(int cnic) {
		
		PersonNode* temp = new PersonNode;
		temp = head;
		
		if(temp->CNIC == cnic) {
			// case when temp is at head, and head is to be deleted
			
			head = head->next;
		}
		else {
			
			while(temp->next->CNIC != cnic) {
				temp = temp->next;
			}
			
			temp->next = temp->next->next;
			
		}
	}
	
	void deleteCell(int cell) {
		
		PersonNode* temp = new PersonNode;
		temp = head;
		
		while(temp != NULL) {
			
			CellNode* ctemp = new CellNode;
			ctemp = temp->down;
			
			if(ctemp->CellNumber == cell) {
				ctemp = ctemp->Down;
			}
			else {
				while(ctemp->Down->CellNumber != cell) {
					ctemp = ctemp->Down;
				}
				ctemp->Down = ctemp->Down->Down;
			}
			
			temp = temp->next;
		}
	}
	
	void addNumber(string name, int num, string nn) {
		
		PersonNode* temp = new PersonNode;
		temp = head;
		
		while(temp->name != name) {
			temp = temp->next;
		}
		temp->down =  addCellNode(temp->down, num, nn);
		
	}
	
	CellNode* addCellNode(CellNode* head, int num, string nn) {
		
		if(head == NULL) {
			
		//	cout << "Entered IF "<< endl;
			
		//	string stemp;
		//	int ntemp;
				
			CellNode* cctemp = new CellNode;
								
			cctemp->CellNumber = num;
			cctemp->NetworkName = nn;
			cctemp->Down = NULL;
			head = cctemp;
		//	cout << "Value entered in first if" << endl;
				
		}
		else {
			CellNode* ctemp2 = new CellNode;
			ctemp2 = head;
		//	while(ctemp2->Down != NULL) {
		//		ctemp2 = ctemp2->Down;
		//	}
			
			CellNode* ctemp3 = new CellNode;
			

			ctemp3->CellNumber = num;
			ctemp3->NetworkName = nn;
			ctemp3->Down = ctemp2;					//adding value at index 0
			//ctemp2->Down = ctemp3;
			
			head = ctemp3;
//			cout << "Value entered in first else" << endl;
				 
		}
			
		return head;
	}
	
	void updateAddress(string name, string newAddress) {
		
		PersonNode* temp = new PersonNode;
		temp = head;
		
		while(temp->name != name) {
			temp = temp->next;
		}
		
		// assuming at this point, temp is at the node with the given name
		
		temp->address = newAddress;
		
	}
	
	void deleteAll() {
		
		cout << "Deleting Database ----------------" << endl;
		
		fstream file;
		file.open("input.txt");
		
		if(!file.is_open()) {
			cout << "File not opened" << endl;
			return;
		}
		
		
		
		while(head != NULL) {
			
			file<<head->CNIC<<" "<< head->name <<" "<<head->FatherName <<" "<< head->gender << " " << head->address <<endl;
			cout << "Deleted : " << head->name << endl;
			
			head = head->next;
		}
		
	}

};

